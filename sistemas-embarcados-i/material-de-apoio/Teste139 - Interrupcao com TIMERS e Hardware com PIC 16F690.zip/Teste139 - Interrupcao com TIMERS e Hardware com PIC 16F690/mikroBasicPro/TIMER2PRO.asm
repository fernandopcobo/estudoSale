
_interrupt:
	MOVWF      R15+0
	SWAPF      STATUS+0, 0
	CLRF       STATUS+0
	MOVWF      ___saveSTATUS+0
	MOVF       PCLATH+0, 0
	MOVWF      ___savePCLATH+0
	CLRF       PCLATH+0

	BTFSS      INTCON+0, 2
	GOTO       L__interrupt2
	INCF       _contador+0, 1
	BTFSC      STATUS+0, 2
	INCF       _contador+1, 1
	MOVF       _contador+1, 0
	XORLW      1
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt33
	MOVLW      244
	XORWF      _contador+0, 0
L__interrupt33:
	BTFSS      STATUS+0, 2
	GOTO       L__interrupt5
	BTFSC      PORTC+0, 0
	GOTO       L__interrupt8
	BSF        PORTC+0, 0
	GOTO       L__interrupt9
L__interrupt8:
	BCF        PORTC+0, 0
L__interrupt9:
	CLRF       _contador+0
	CLRF       _contador+1
L__interrupt5:
	BTFSS      PORTA+0, 3
	GOTO       L__interrupt11
	BSF        PORTC+0, 2
	GOTO       L__interrupt12
L__interrupt11:
	BCF        PORTC+0, 2
L__interrupt12:
	BCF        INTCON+0, 2
L__interrupt2:
	BTFSS      INTCON+0, 1
	GOTO       L__interrupt14
	BTFSS      PORTA+0, 2
	GOTO       L__interrupt17
	BCF        PORTC+0, 1
	MOVLW      64
	SUBWF      OPTION_REG+0, 1
L__interrupt17:
	BTFSC      PORTA+0, 2
	GOTO       L__interrupt20
	BSF        PORTC+0, 1
	MOVLW      64
	ADDWF      OPTION_REG+0, 1
L__interrupt20:
	BCF        INTCON+0, 1
L__interrupt14:
L_end_interrupt:
L__interrupt32:
	MOVF       ___savePCLATH+0, 0
	MOVWF      PCLATH+0
	SWAPF      ___saveSTATUS+0, 0
	MOVWF      STATUS+0
	SWAPF      R15+0, 1
	SWAPF      R15+0, 0
	RETFIE
; end of _interrupt

_main:

	MOVLW      255
	MOVWF      TRISA+0
	MOVLW      255
	MOVWF      TRISB+0
	CLRF       TRISC+0
	CLRF       ANSEL+0
	CLRF       ANSELH+0
	MOVLW      241
	MOVWF      INTCON+0
	MOVLW      209
	MOVWF      OPTION_REG+0
	CLRF       PORTC+0
	CLRF       _contador+0
	CLRF       _contador+1
	MOVF       TMR0+0, 0
	MOVWF      R1+0
	MOVLW      1
	MOVWF      R0+0
	MOVF       R1+0, 0
L__main35:
	BTFSC      STATUS+0, 2
	GOTO       L__main36
	RLF        R0+0, 1
	BCF        R0+0, 0
	ADDLW      255
	GOTO       L__main35
L__main36:
	COMF       R0+0, 1
	MOVF       R0+0, 0
	ANDWF      INTCON+0, 1
	BCF        INTCON+0, 1
	BSF        PORTC+0, 1
L__main27:
	GOTO       L__main27
L_end_main:
	GOTO       $+0
; end of _main
